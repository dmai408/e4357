/*
Author: David Mai
Purpose: Firmware Essentials Final Project
Professor: Shengliang Song
Date: 12/9/2013
*/

#include "mbed.h"

Serial pc(USBTX, USBRX); // tx, rx
I2C i2c_port(p9,p10);

const int deviceaddress = 0x16;

//Word Commands
#define batt_voltage 0x09
#define batt_percentage 0x0d
#define batt_designCap 0x18
#define batt_current 0x0a
#define batt_runTime 0x13
#define batt_temp 0x08

//Block Commands
#define batt_chemistry 0x22
#define batt_mfgr 0x20
#define batt_device 0x21

int smb_read_word(char command, unsigned int &output);
int smb_read_block(char command, char *value, int byteLen);
void batt_data();

int main(void) {

    unsigned int output;
    char block_output[8];
   
    pc.baud(9600);
    i2c_port.frequency(50000);

        while(1)
        {
            if(smb_read_block(batt_mfgr, block_output, 4))
            pc.printf("Mfg: %c%c%c%c, ", block_output[0], block_output[1], block_output[2], block_output[3]);
           
            if(smb_read_block(batt_device, block_output, 6))
            pc.printf("Dev: %c%c%c%c%c%c, ", block_output[0], block_output[1], block_output[2], block_output[3], block_output[4],
            block_output[5]);
           
            if(smb_read_block(batt_chemistry, block_output, 5))
            pc.printf("Chem: %c%c%c%c%c, ", block_output[0], block_output[1], block_output[2], block_output[3], block_output[4]);
           
            if(smb_read_word(batt_designCap, output))   
            pc.printf("Design Capacity: %d mAh \n\r", output);
           
            for(int i = 0; i < 10; i++)
            {
                batt_data();
                wait(1);
            }
            printf("\n\r");
        }
       
       
}

void batt_data()
{
        unsigned int output;
   
        if(smb_read_word(batt_voltage, output))       
    pc.printf("%.3f V, ", (float)output/1000);
       
        if(smb_read_word(batt_current, output))       
    pc.printf("%.3f A, ", (float)output);
       
      if(smb_read_word(batt_temp, output))       
    pc.printf("%.2f F, ", ((float)output/10 - 273.15)*1.8 + 32);
       
      if(smb_read_word(batt_percentage, output))       
    pc.printf("%d%%, ", output);
       
      if(smb_read_word(batt_runTime, output))   
    pc.printf("%d min remaining \n\r", output);
}

int smb_read_word(char command, unsigned int &output)
{
    char *comm;
    char value[2];
    comm = &command;
   
    if(i2c_port.write(deviceaddress, comm, 1, true) == 1)
    {
        pc.printf("Failed to communicate \n\r");
        return 0;
    }
   
    if(i2c_port.read(deviceaddress, value, 2) == 1)
    {
        pc.printf("Failed to communicate \n\r");
        return 0;
    }
       
    output = value[0] + (value[1] << 8);
    return 1;
}

int smb_read_block(char command, char *value, int byteLen)
{
    char *comm;
    comm = &command;
   
    if(i2c_port.write(deviceaddress, comm, 1, true) == 1)
    {
        pc.printf("Failed to communicate \n\r");
        return 0;
    }
   
    if(i2c_port.read(deviceaddress, value, byteLen) == 1)
    {
        pc.printf("Failed to communicate \n\r");
        return 0;
    }
       
    return 1;
}
